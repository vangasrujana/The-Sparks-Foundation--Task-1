# Sparks-Foundation-Task1
Basic Banking system
